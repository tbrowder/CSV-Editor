# CSV::Editor

A simple cross‑platform visual CSV **text** editor for Raku.

- Opens a plain‑text “CSV” file (separator can be `|`, `,`, or `;`)
- Shows it in a resizable GUI with **Save**, **Exit**, and **FitWidth** buttons
- Honors `#` comment records and an `=finish` sentinel record
- Normalizes whitespace around separators when fitting widths

## Quick start

```bash
# Install dependencies
zef install .        # inside this repo
# or explicitly
zef install GTK::Simple

# Run
bin/csv-edit path/to/file.txt
```

### Status

This is a **skeleton** with a working parser/formatter and a basic GTK GUI.
GUI tests are intentionally omitted so CI does not need GTK packages.
